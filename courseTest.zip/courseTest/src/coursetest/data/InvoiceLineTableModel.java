/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coursetest.data;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import static jdk.internal.org.jline.utils.InfoCmp.Capability.columns;

/**
 *
 * @author Habiba
 */
public class InvoiceLineTableModel extends AbstractTableModel {

    private ArrayList<InvTableLine> linesArray;
   

    public InvoiceLineTableModel(ArrayList<InvTableLine> linesArray) {
        this.linesArray = linesArray;
    }

    @Override
    public int getRowCount() {
        return linesArray == null ? 0 : linesArray.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (linesArray == null) {
            return "";
        } else {
            InvTableLine line = linesArray.get(rowIndex);
            switch (columnIndex) {
                case 0:
                    return line.getItem();
                case 1:
                    return line.getPrice();
                case 2:
                    return line.getCount();
                case 3:
                    return line.getLineTotal();
                default:
                    return "";
            }
        }
    }

    @Override
    public String getColumnName(int column) {
        switch(column){
            case 0: return "No.";
            case 1: return "Item Name";
            case 2: return "Item Price";
            case 3: return "Count";
            case 4: return "Item Total";
        
        }
        
        
        
        return "";
    }
 public ArrayList<InvTableLine> getArrInvoiceLine() {
        return linesArray;
}
 public void setArrInvoiceLine(ArrayList<InvTableLine> linesArray) {
        this.linesArray = linesArray;
}}